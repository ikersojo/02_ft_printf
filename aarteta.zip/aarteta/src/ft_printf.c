/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/08 12:54:51 by aarteta           #+#    #+#             */
/*   Updated: 2022/10/10 21:27:24 by aarteta          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"
#include <stdarg.h>

static int	ft_value(va_list ap, char c)
{
	int	len;

	len = 0;
	if (c == 'c')
		len += ft_putchar(va_arg(ap, int));
	else if (c == 's')
		len += ft_putstr(va_arg(ap, char *));
	else if ((c == 'i') || (c == 'd'))
		len += ft_putnbr(va_arg(ap, int));
	else if ((c == 'x') || (c == 'X'))
		len += ft_puthex(va_arg(ap, unsigned int), c);
	else if (c == 'p')
		len += ft_putstr("0x") + ft_puthex(va_arg(ap, size_t), c);
	else if (c == 'u')
		len += ft_putunbr(va_arg(ap, unsigned int));
	else if (c == '%')
		len += ft_putchar('%');
	return (len);
}

int	ft_printf(const char *format, ...)
{
	va_list	ap;
	int		len;

	len = 0;
	va_start (ap, format);
	while (*format != '\0')
	{
		if (*format == '%')
		{
			len += ft_value(ap, *++format);
		}
		else
		{
			len += ft_putchar(*format);
		}
		format++;
	}
	va_end(ap);
	return (len);
}
