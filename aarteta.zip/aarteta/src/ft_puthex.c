/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_puthex.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aarteta <aarteta@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/10 19:55:18 by aarteta           #+#    #+#             */
/*   Updated: 2022/10/10 21:34:19 by aarteta          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/ft_printf.h"

int	ft_puthex(size_t adr, char c)
{
	int	len;

	len = 0;
	if ((c == 'x') || (c == 'p'))
	{
		if (adr >= 16)
			len += ft_puthex(adr / 16, c);
		len += ft_putchar("0123456789abcdef"[adr % 16]);
		return (len);
	}
	if (c == 'X')
	{
		if (adr >= 16)
			len += ft_puthex(adr / 16, c);
		len += ft_putchar("0123456789ABCDEF"[adr % 16]);
		return (len);
	}
	return (0);
}
